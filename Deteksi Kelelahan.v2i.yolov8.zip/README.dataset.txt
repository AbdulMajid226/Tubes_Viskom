# Deteksi Kelelahan > 2025-12-23 5:28pm
https://universe.roboflow.com/matkul-komputer-vision/deteksi-kelelahan

Provided by a Roboflow user
License: CC BY 4.0

